

Estimating Racial Disparities in Emergency General Surgery
Eli Ben-Michael, Avi Feller, Rachel Kelz, Luke Keele
Sept 9, 2024

This document describes the replication files for the above paper. The archive contains all of the programs used in the analysis. 

Application

For this application data are publicly available, but require obtaining a data use agreement from the states of PA, FL, and NY. Data must also be purchased from each state. As such, we do not include the data, but include all the R scripts used in the analysis.

1. Table-1 -- R script to create Table 1.
2. Weight-Estimation
 - Basis Selection
	-Intertaction-Detect-Allow-T.R  Random Forest Fits for Race.
        -Intertaction-Detect-Allow-T.R  Random Forest Fits for Race Using Allowable Y  Covariates.
        -Intertaction-Detect-Allow-Surg.R  Random Forest Fits for Race with Surgery Population.
        -Intertaction-Detect-Allow-NSurg.R  Random Forest Fits for Race with Non-Surgery Population.
	-Int-Summary.R Summarize RF fits.
 -Hyperparamter Selection.R. Selects Hyperparameter Values for Weights
 -Weight-Estimation.R Fits estimated weights. Includes weights for within hospitals as well as those used in the stochastic intervention and decomposition estimates.


3. Figure-1 -- Computes results for Figure 1.
4. Figures-2-3 -- Computes results for Figures 2 and 3.
5. Figure-4 -- Computes matches for Surgical and Non-Surgical populations. Figure-4.R then computes the two figures comparing weighting to matching.
6. Tables-2-5 -- Estimates outcomes based on weights for Tables 2-5.  Print-Tables-2-5.R generates the results in the Tables.

 