
library(foreign)
library(dplyr)
library(xtable)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)

data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)
nrow(data)

data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
table(data$surg)
prop.table(table(data$surg))
table(data$afam)
length(unique(data$hosp))

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]


out <- data %>% group_by(afam) %>% 
   summarize(across(c("adverse", "los", "surg"),  ~ mean(.x))) %>% as.data.frame()
out
        
## Balance
all.cov <- c("age","comorb", "female",
           "angus", "disability_bin",
           "under65",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51", "surg")
             
data.var <- data %>% group_by(afam) %>% 
   summarize(across(all.cov, ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.sd <- sqrt((t.var + c.var/2))


um.wt <- data %>% group_by(afam) %>% 
   summarize(across(all.cov, ~mean(.x))) %>% as.data.frame()

           
um.wt.tab <- matrix(NA, length(all.cov), 3)
um.wt.tab[,1] <- unlist(um.wt[1,-1]) 
um.wt.tab[,2] <- unlist(um.wt[2,-1])                        
um.wt.tab[,3] <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.sd


### Table
n_covs <- length(all.cov)

var_names <- c("Age", "No. Comorbidities", "Female", 
               "Sepsis", "Disability","Under 65",
               "Medicare", "Medicaid", "Private Insurance", "Self Insurance", "Other",
               "Congestive Heart Failure",  "Cardiac Arrhythmias","Valvular Disease",
               "Pulmonary Circulation Disorders", "Peripheral Vascular Disorders",
               "Hypertension, Uncomplicated","Paralysis", "Other Neurological Disorders", 
               "Chronic Pulmonary Disease","Diabetes, Uncomplicated",
               "Diabetes, Complicated","Hypothyroidism", "Renal Failure","Liver Disease",
               "Peptic Ulcer Disease Excluding Bleeding","AIDS/HIV", "Lymphoma","Metastatic Cancer",
               "Solid Tumor Without Metastasis","Rheumatoid Arthritis/Collagen Vascular",
               "Coagulopathy","Obesity","Weight Loss","Fluid and Electrolyte Disorders",
               "Blood Loss Anemia","Deficiency Anemia","Alcohol Abuse","Drug Abuse",
               "Psychoses","Depression","Hypertension, Complicated",
               "Colorectal: Bleeding","Colorectal: Cancer","Colorectal: Colitis",
               "Colorectal: Diverticulitis","Colorectal: Fistula","Colorectal:Hemorrhage","Colorectal: Megacolon",
               "Colorectal:Colostomy/Ileostomy","Colorectal:Rectal Prolapse",
               "Colorectal: Regional Enteritis","Colorectal: Anorectal Stenosis, Polyp, Ulcer, NEC",
               "Gen Abdominal: RP Abscess","Gen Abdominal: Hemoperitoneum","Gen Abdominal: Abdominal Mass",
               "Gen Abdominal: Abdominal Pain","Gen Abdominal:
               Peritonitis","HPB: Gallstones and Related Diseases","HPB: Hepatic","HPB: Pancreatitis",
               "Hernia: Diaphragmatic","Hernia:Femoral","Hernia: Incisional",
               "Hernia:Inguinal","Hernia: Other","Hernia:Umbilical","Hernia:Ventral","Intestinal Obstruction: Adhesions",
               "Intestinal Obstruction:Incarcerated Hernias","Intestinal Obstruction: Intussusceptions",
               "Intestinal Obstruction: Obstruction",
               "Intestinal Obstruction: Volvulus","Resuscitation: Acute Respiratory Failure",
               "Resuscitation: Shock","Skin & Soft Tissue: Abscesses","Skin & Soft Tissue: Cellulitis",
               "Skin & Soft Tissue: Compartment Syndrome","Skin & Soft Tissue: Fasciitis",
               "Skin & Soft Tissue: Pressure Ulcers","Skin & Soft Tissue: Wound Care","Upper GI: Appendix",
               "Upper GI: Bleed","Upper GI: Bowel Perforation","Upper GI: Fistula",
               "Upper GI: Gastrostomy","Upper GI: Ileus","Upper GI: Meckel's","Upper GI: Peptic Ulcer Disease",
               "Upper GI: Small Intestinal Cancers","Vascular Acute Intestinal Ischemia",
               "Vascular: Acute Peripheral Ischemia","Vascular: Phlebitis", "Surgery")
               
              
rownames(um.wt.tab) <- var_names
colnames(um.wt.tab) <- c("Whites", "Blacks", "Std. Diff.")

tab.1 <- um.wt.tab[which(abs(um.wt.tab[,3]) > .15),]
tab.1[,1] <- c(round(tab.1[1,1], 1), round((tab.1[2:9,1])*100, 1))
tab.1[,2] <- c(round(tab.1[1,2], 1), round((tab.1[2:9,2])*100, 1))

tab.1
xtable(tab.1, digits = c(1,1,1,2))            
            
              
            