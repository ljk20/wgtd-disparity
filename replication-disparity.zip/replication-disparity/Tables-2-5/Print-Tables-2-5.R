

library(ggplot2)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("restrict-wts.outcomes.RData")
load("unadj-outcomes.RData")
load("new-wts.outcomes.RData")

### Table 2

## Rows 1-2
cat("Point Estimate  &", round(adv.out[1], 3), "&",  round(ob.disp[1], 4), "&", round(adv.state.out[1], 3), "&",  round(adv.hosp.out[1], 4)," \\\\ 
95\\% Confidence Interval  & [", round(adv.out[2], 3), ",", round(adv.out[3], 3), "] & [", round(ob.disp[2], 3), ",", round(ob.disp[3], 3), "] & [",
round(adv.state.out[2], 3), ",", round(adv.state.out[3], 3), "] & [", round(adv.hosp.out[2], 3), ",", round(adv.hosp.out[3], 3), "]  \\\\ \n")

## Rows 3-4
cat("Point Estimate  &", round(adv.or.out[1], 2), "&",  round(ob.disp.rr[1], 2), "&", round(adv.or.state.out[1], 2), "&",  round(adv.or.hosp.out[1], 2)," \\\\ 
95\\% Confidence Interval  & [", round(adv.or.out[2], 2), ",", round(adv.or.out[3], 2), "] & [", round(ob.disp.rr[2], 2), ",", 
round(ob.disp.rr[3], 2), "] & [", round(adv.or.state.out[2], 2), ",", round(adv.or.state.out[3], 2), "] & [", round(adv.or.hosp.out[2], 2), ",", 
round(adv.or.hosp.out[3], 2), "]  \\\\ \n")

## Rows 5-6
cat("Point Estimate  &", round(los.out[1], 5), "&",  round(ob.disp.los[1], 2), "&", round(los.state.out[1], 2), "&",  round(los.hosp.out[1], 2)," \\\\ 
95\\% Confidence Interval  & [", round(los.out[2], 2), ",", round(los.out[3], 2), "] & [", round(ob.disp.los[2], 2), ",", round(ob.disp.los[3], 2), "] & [",
round(los.state.out[2], 2), ",", round(los.state.out[3], 2), "] & [", round(los.hosp.out[2], 2), ",", round(los.hosp.out[3], 2), "]  \\\\ \n")




## Table 3
## Rows 1-2
cat("Point Estimate  &", round(adv.out.s[1], 5), "&",  round(adv.state.out.s[1], 2), "&",  round(adv.hosp.out.s[1], 2)," \\\\ 
95\\% Confidence Interval  & [", round(adv.out.s[2], 2), ",", round(adv.out.s[3], 2), "] & [", 
round(adv.state.out.s[2], 2), ",", round(adv.state.out.s[3], 2), "] & [", round(adv.hosp.out.s[2], 2), ",", round(adv.hosp.out.s[3], 2), "]  \\\\ \n")

## Rows 3-4
cat("Point Estimate  &", round(adv.or.out.s[1], 2), "&",  round(adv.or.state.out.s[1], 2), "&",  round(adv.or.hosp.out.s[1], 2)," \\\\ 
95\\% Confidence Interval  & [", round(adv.or.out.s[2], 2), ",", round(adv.or.out.s[3], 2), "] & [",
 round(adv.or.state.out.s[2], 2), ",", round(adv.or.state.out.s[3], 2), "] & [", round(adv.or.hosp.out.s[2], 2), ",", 
round(adv.or.hosp.out.s[3], 2), "]  \\\\ \n")

## Rows 5-6
cat("Point Estimate  &", round(los.out.s[1], 2), "&",  round(los.state.out.s[1], 2), "&",  round(los.hosp.out.s[1], 2)," \\\\ 
95\\% Confidence Interval  & [", round(los.out.s[2], 2), ",", round(los.out.s[3], 2), "] & [", 
round(los.state.out.s[2], 2), ",", round(los.state.out.s[3], 2), "] & [", round(los.hosp.out.s[2], 2), ",", round(los.hosp.out.s[3], 2), "]  \\\\ \n")


## Table 4
rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("new-wts.outcomes.RData")

## Rows 1-2
cat("Point Estimate  &", round(ob.disp[1], 3), "&",  round(post.int[1], 4), "&",
round(remain.disp[1], 4), " \\\\ 
95\\% Confidence Interval  & [", round(ob.disp[2], 3), ",", round(ob.disp[3], 3), "] & [",
round(post.int[2], 3), ",", round(post.int[3], 3), "] & [",
round(remain.disp[2], 3), ",", round(remain.disp[3], 3), "]  \\\\ \n")

## Rows 3-4
cat("Point Estimate  &", round(ob.disp.los[1], 2), "&",  round(post.int.los[1], 3), "&",
round(remain.disp.los[1], 2), " \\\\ 
95\\% Confidence Interval  & [", round(ob.disp.los[2], 2), ",", round(ob.disp.los[3], 2), "] & [",
round(post.int.los[2], 2), ",", round(post.int.los[3], 2), "] & [",
round(remain.disp.los[2], 2), ",", round(remain.disp.los[3], 2), "]  \\\\ \n")

## Table 5
rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("decomp.two.outcomes.RData")

## Rows 1-2
cat("Point Estimate  &", round(tot[1], 3), "&",  round(base[1], 3), "&",
round(prev[1], 5), "&",   round(eff[1], 3), "&", round(select[1], 5), " \\\\ 
95\\% Confidence Interval  & [", round(tot[2], 3), ",", round(tot[3], 3), "] & [",
round(base[2], 3), ",", round(base[3], 3), "] & [",
round(prev[2], 5), ",", round(prev[3], 5), "] & [",
round(eff[2], 3), ",", round(eff[3], 3), "] & [",
round(select[2], 3), ",", round(select[3], 3), "]  \\\\ \n")

## Rows 3-4
cat("Point Estimate  &", round(tot.los[1], 3), "&",  round(base.los[1], 3), "&",
round(prev.los[1], 3), "&",   round(eff.los[1], 3), "&", round(select.los[1], 3), " \\\\ 
95\\% Confidence Interval  & [", round(tot.los[2], 3), ",", round(tot.los[3], 3), "] & [",
round(base.los[2], 3), ",", round(base.los[3], 3), "] & [",
round(prev.los[2], 3), ",", round(prev.los[3], 3), "] & [",
round(eff.los[2], 3), ",", round(eff.los[3], 3), "] & [",
round(select.los[2], 5), ",", round(select.los[3], 3), "]  \\\\ \n")


