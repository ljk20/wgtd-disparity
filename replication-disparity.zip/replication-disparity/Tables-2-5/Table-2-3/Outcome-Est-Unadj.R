library(foreign)
library(dplyr)
library(xtable)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)

#setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
#load("wts.out.RData")

data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]

data.s <- data %>% filter(surg==1)
data.ns <- data %>% filter(surg==0)
data$los[data$los>30] <- 30

# Process the Weights
data.s$wts.hosp <- out.hosp.surg$weights
data.s$wts.hosp[data.s$afam == 1] <- 1

data.s$wts.state <- out.state.surg$weights
data.s$wts.state[data.s$afam == 1] <- 1

data.ns$wts.hosp <- out.hosp.nsurg$weights
data.ns$wts.hosp[data.ns$afam == 1] <- 1

data.ns$wts.state <- out.state.nsurg$weights
data.ns$wts.state[data.ns$afam == 1] <- 1

data.m <- rbind(data.s, data.ns)


## Full Pop Estimates

out.unadj <- data %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los", "died", "complication", "prolonged"),  ~ mean(.x))) %>% as.data.frame()
out.unadj
out.unadj[1,] - out.unadj[2,]

## Risk Difference
adv.rd <- lm(adverse ~ afam, data=data)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
adv.out <- c(pe, ci.1, ci.2)


## Risk Ratio
adv.or <- glm(adverse ~ afam, data=data, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
adv.or.out <- c(pe, ci.1, ci.2)

###### LOS
los <- lm(los ~ afam, data=data)
pe <- los$coef[2]
ci.1 <- confint(los)[2,1]
ci.2 <- confint(los)[2,2]
los.out <- c(pe, ci.1, ci.2)

tr.out <- data$los[data$afam==1]
ctl.out <- data$los[data$afam==0]
median(tr.out)
median(ctl.out)
c(IQR(tr.out), IQR(ctl.out))


###### Mortality
## Risk Difference
adv.rd <- lm(died ~ afam, data=data)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
died.out <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(died ~ afam, data=data, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
died.or.out <- c(pe, ci.1, ci.2)


###### Complications
## Risk Difference
adv.rd <- lm(complication ~ afam, data=data)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
comp.out <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(complication ~ afam, data=data, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
comp.or.out <- c(pe, ci.1, ci.2)

###### PLOS
## Risk Difference
adv.rd <- lm(prolonged ~ afam, data=data)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
plos.out <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(prolonged ~ afam, data=data, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
plos.or.out <- c(pe, ci.1, ci.2)


### Surgery Estimates
out.unadj.s <- data.s %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los", "died", "complication", "prolonged"),  ~ mean(.x))) %>% as.data.frame()
out.unadj
out.unadj[1,] - out.unadj[2,]


## Risk Difference
adv.rd <- lm(adverse ~ afam, data=data.s)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
adv.out.s <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(adverse ~ afam, data=data.s, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
adv.or.out.s <- c(pe, ci.1, ci.2)

###### LOS
los <- lm(los ~ afam, data=data.s)
pe <- los$coef[2]
ci.1 <- confint(los)[2,1]
ci.2 <- confint(los)[2,2]
los.out.s <- c(pe, ci.1, ci.2)

###### Mortality
## Risk Difference
adv.rd <- lm(died ~ afam, data=data.s)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
died.out.s <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(died ~ afam, data=data.s, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
died.or.out.s <- c(pe, ci.1, ci.2)


###### Complications
## Risk Difference
adv.rd <- lm(complication ~ afam, data=data.s)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
comp.out.s <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(complication ~ afam, data=data.s, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
comp.or.out.s <- c(pe, ci.1, ci.2)

###### PLOS
## Risk Difference
adv.rd <- lm(prolonged ~ afam, data=data.s)
pe <- adv.rd$coef[2]
ci.1 <- confint(adv.rd)[2,1]
ci.2 <- confint(adv.rd)[2,2]
plos.out.s <- c(pe, ci.1, ci.2)

## Risk Ratio
adv.or <- glm(prolonged ~ afam, data=data.s, family=poisson())
pe <- exp(adv.or$coef[2])
ci.1 <- exp(confint(adv.or))[2,1]
ci.2 <- exp(confint(adv.or))[2,2]
plos.or.out.s <- c(pe, ci.1, ci.2)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(adv.out,
     adv.or.out,
	 los.out,
	 died.out,
     died.or.out,
     comp.out,
     comp.or.out,
     plos.out,
     plos.or.out,
	 adv.out.s,
     adv.or.out.s,
	 los.out.s,
	 died.out.s,
     died.or.out.s,
     comp.out.s,
     comp.or.out.s,
     plos.out.s,
     plos.or.out.s,
	file ="unadj-outcomes.RData")
        