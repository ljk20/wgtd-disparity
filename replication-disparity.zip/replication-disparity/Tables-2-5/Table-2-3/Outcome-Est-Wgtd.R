
library(foreign)
library(dplyr)
library(tidyverse)
library(sandwich)
library(geepack)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("wts.out.RData")

data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
data$los[data$los>30] <- 30

setwd("/Volumes/C-SHE/Keele/Template Ranks/Analysis/ReplicationFiles/routput")
load("ridge-resid.RData") 
data$Y.res.a <- rd.resid.a
data$Y.res.l <- rd.resid.l
nrow(data)
length(rd.resid.a)

data.s <- data %>% filter(surg==1)
data.ns <- data %>% filter(surg==0)

# Process the Weights
data.s$wts.hosp <- out.hosp.surg$weights
data.s$wts.hosp[data.s$afam == 1] <- 1

data.s$wts.state <- out.state.surg$weights
data.s$wts.state[data.s$afam == 1] <- 1

data.ns$wts.hosp <- out.hosp.nsurg$weights
data.ns$wts.hosp[data.ns$afam == 1] <- 1

data.ns$wts.state <- out.state.nsurg$weights
data.ns$wts.state[data.ns$afam == 1] <- 1

data.m <- rbind(data.s, data.ns)

## Full Pop Estimates

out.unadj <- data.m %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ mean(.x))) %>% as.data.frame()
out.unadj
out.unadj[1,] - out.unadj[2,]

out.resid <- data.m %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ weighted.mean(.x, wts.hosp))) %>% as.data.frame()
out.resid
out.resid[1,] - out.resid[2,]   
     
     mu0 <- out.resid[1,2]
     mu1 <- out.resid[2,2]
     pe.a <-  mu1 - mu0
     v1 <- var(data.m$adverse[data.m$afam == 1]) / sum(data.m$afam == 1)
     v0 <- sum((data.m$Y.res.a[data.m$afam == 0])^2 * data.m$wts.hosp[data.m$afam == 0]^2) / sum(data.m$wts.hosp[data.m$afam == 0])^2
     bm.se <- sqrt(v1) + sqrt(v0)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     adv.hosp.out <- c(pe.a, bm.ci.1, bm.ci.2)
     
     log.rr =  log(mu1) - log(mu0)
     rr.a = exp(log.rr)
     se_log_risk_ratio = sqrt((((1/ mu1) ^ 2 * v1) + ((1/ mu0) ^ 2 * v0)))
     
     bm.ci.1 <- log.rr - abs(qnorm(.025))*se_log_risk_ratio
     bm.ci.2 <- log.rr + abs(qnorm(.025))*se_log_risk_ratio
     adv.or.hosp.out <- c(rr.a, exp(bm.ci.1), exp(bm.ci.2))

					  
     mu0 <- out.resid[1,3]
     mu1 <- out.resid[2,3]
     pe.l <-  mu1 - mu0
     se1 <- sqrt(var(data.m$los[data$afam == 1]) / sum(data.m$afam == 1))
     se2 <- sqrt(sum((data$Y.res.l[data.m$afam == 0])^2 * data.m$wts.hosp[data.m$afam == 0]^2) / sum(data.m$wts.hosp[data.m$afam == 0])^2)
     bm.se <- se1 + se2
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     los.hosp.out <- c(pe.l, bm.ci.1, bm.ci.2)	
     
     
     ## State Results
     out.resid <- data.m %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ weighted.mean(.x, wts.state))) %>% as.data.frame()
out.resid
        
     mu0 <- out.resid[1,2]
     mu1 <- out.resid[2,2]
     pe.a <-  mu1 - mu0
     v1 <- var(data.m$adverse[data.m$afam == 1]) / sum(data.m$afam == 1)
     v0 <- sum((data.m$Y.res.a[data.m$afam == 0])^2 * data.m$wts.state[data.m$afam == 0]^2) / sum(data.m$wts.state[data.m$afam == 0])^2
     bm.se <- sqrt(v1) + sqrt(v0)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     adv.state.out <- c(pe.a, bm.ci.1, bm.ci.2)
     
     log.rr =  log(mu1) - log(mu0)
     rr.a = exp(log.rr)
     se_log_risk_ratio = sqrt((((1/ mu1) ^ 2 * v1) + ((1/ mu0) ^ 2 * v0)))
     
     bm.ci.1 <- log.rr - abs(qnorm(.025))*se_log_risk_ratio
     bm.ci.2 <- log.rr + abs(qnorm(.025))*se_log_risk_ratio
     adv.or.state.out <- c(rr.a, exp(bm.ci.1), exp(bm.ci.2))

					  
     mu0 <- out.resid[1,3]
     mu1 <- out.resid[2,3]
     pe.l <-  mu1 - mu0
     se1 <- sqrt(var(data.m$los[data$afam == 1]) / sum(data.m$afam == 1))
     se2 <- sqrt(sum((data$.mY.res.l[data.m$afam == 0])^2 * data.m$wts.state[data.m$afam == 0]^2) / sum(data.m$wts.state[data.m$afam == 0])^2)
     bm.se <- se1 + se2
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     los.state.out <- c(pe.l, bm.ci.1, bm.ci.2)	
     
     
## Surgery Group
out.unadj <- data.s %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ mean(.x))) %>% as.data.frame()
out.unadj
out.unadj[1,] - out.unadj[2,]
     
out.resid <- data.s %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ weighted.mean(.x, wts.hosp))) %>% as.data.frame()
out.resid
out.resid[1,] - out.resid[2,] 
        
     mu0 <- out.resid[1,2]
     mu1 <- out.resid[2,2]
     pe.a <-  mu1 - mu0
     v1 <- var(data.s$adverse[data.s$afam == 1]) / sum(data.s$afam == 1)
     v0 <- sum((data.s$Y.res.a[data.s$afam == 0])^2 * data.s$wts.hosp[data.s$afam == 0]^2) / sum(data.s$wts.hosp[data.s$afam == 0])^2
     bm.se <- sqrt(v1) + sqrt(v0)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     adv.hosp.out.s <- c(pe.a, bm.ci.1, bm.ci.2)
     
     log.rr =  log(mu1) - log(mu0)
     rr.a = exp(log.rr)
     se_log_risk_ratio = sqrt((((1/ mu1) ^ 2 * v1) + ((1/ mu0) ^ 2 * v0)))
     
     bm.ci.1 <- log.rr - abs(qnorm(.025))*se_log_risk_ratio
     bm.ci.2 <- log.rr + abs(qnorm(.025))*se_log_risk_ratio
     adv.or.hosp.out.s <- c(rr.a, exp(bm.ci.1), exp(bm.ci.2))

					  
     mu0 <- out.resid[1,3]
     mu1 <- out.resid[2,3]
     pe.l <-  mu1 - mu0
     se1 <- sqrt(var(data.s$los[data.s$afam == 1]) / sum(data.s$afam == 1))
     se2 <- sqrt(sum((data.s$Y.res.l[data.s$afam == 0])^2 * data.s$wts.hosp[data.s$afam == 0]^2) / sum(data.s$wts.hosp[data.s$afam == 0])^2)
     bm.se <- se1 + se2
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     los.hosp.out.s <- c(pe.l, bm.ci.1, bm.ci.2)	
     
     
     ## State Results
     out.resid <- data.s %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ weighted.mean(.x, wts.state))) %>% as.data.frame()
out.resid
out.resid[1,] - out.resid[2,] 
        
     mu0 <- out.resid[1,2]
     mu1 <- out.resid[2,2]
     pe.a <-  mu1 - mu0
     v1 <- var(data.s$adverse[data.s$afam == 1]) / sum(data.s$afam == 1)
     v0 <- sum((data.s$Y.res.a[data.s$afam == 0])^2 * data.s$wts.state[data.s$afam == 0]^2) / sum(data.s$wts.state[data.s$afam == 0])^2
     bm.se <- sqrt(v1) + sqrt(v0)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     adv.state.out.s <- c(pe.a, bm.ci.1, bm.ci.2)
     
     log.rr =  log(mu1) - log(mu0)
     rr.a = exp(log.rr)
     se_log_risk_ratio = sqrt((((1/ mu1) ^ 2 * v1) + ((1/ mu0) ^ 2 * v0)))
     
     bm.ci.1 <- log.rr - abs(qnorm(.025))*se_log_risk_ratio
     bm.ci.2 <- log.rr + abs(qnorm(.025))*se_log_risk_ratio
     adv.or.state.out.s <- c(rr.a, exp(bm.ci.1), exp(bm.ci.2))

					  
     mu0 <- out.resid[1,3]
     mu1 <- out.resid[2,3]
     pe.l <-  mu1 - mu0
     se1 <- sqrt(var(data.s$los[data.s$afam == 1]) / sum(data.s$afam == 1))
     se2 <- sqrt(sum((data$.mY.res.l[data.s$afam == 0])^2 * data.s$wts.state[data.s$afam == 0]^2) / sum(data.s$wts.state[data.s$afam == 0])^2)
     bm.se <- se1 + se2
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     los.state.out.s <- c(pe.l, bm.ci.1, bm.ci.2)	
             		  

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(adv.hosp.out,
	los.hosp.out,
	adv.or.hosp.out,
	adv.state.out,
	los.state.out,
	adv.or.state.out,
    adv.hosp.out.s,
	los.hosp.out.s,
	adv.or.hosp.out.s,
	adv.state.out.s,
	los.state.out.s,
	adv.or.state.out.s,
	file ="restrict-wts.outcomes.RData")


                    
