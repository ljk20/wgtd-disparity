
library(foreign)
library(dplyr)
library(tidyverse)
library(sandwich)
library(geepack)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("wts.out.RData")

data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
data$los[data$los>30] <- 30

setwd("/Volumes/C-SHE/Keele/Template Ranks/Analysis/ReplicationFiles/routput")
load("ridge-resid.RData") 
data$Y.res.a <- rd.resid.a
data$Y.res.l <- rd.resid.l
nrow(data)
length(rd.resid.a)


# Process the Weights
data$allow.y.wts <- out.y$weights
data.s <- data %>% filter(surg==1)
data.ns <- data %>% filter(surg==0)

data.m <- rbind(data.s, data.ns)

out.unadj <- data.m %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ mean(.x))) %>% as.data.frame()
out.unadj

out.resid <- data.m %>% group_by(afam) %>% 
       summarize(across(c("adverse", "los"),  ~ weighted.mean(.x, allow.y.wts))) %>% as.data.frame()
out.resid

## observed disparity standardizing for A towards the "1" group
     mu1 <- mean(data.m$adverse[data.m$afam == 1])
     mu0 <- sum(data.m$adverse[data.m$afam == 0] * data.m$allow.y.wts[data.m$afam == 0]) / sum(data.m$afam == 1)
     # estimated observed disparity
     pe.a <-  mu1 - mu0
     v1 <- var(data.m$adverse[data.m$afam == 1]) / sum(data.m$afam == 1)
     v0 <- sum((data.m$Y.res.a[data.m$afam == 0])^2 * data.m$allow.y.wts[data.m$afam == 0]^2) / sum(data.m$allow.y.wts[data.m$afam == 0])^2
     bm.se <- sqrt(v1) + sqrt(v0)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     ob.disp <- c(pe.a, bm.ci.1, bm.ci.2)
     
     log.rr =  log(mu1) - log(mu0)
     rr.a = exp(log.rr)
     se_log_risk_ratio = sqrt((((1/ mu1) ^ 2 * v1) + ((1/ mu0) ^ 2 * v0)))
     bm.ci.1 <- log.rr - abs(qnorm(.025))*se_log_risk_ratio
     bm.ci.2 <- log.rr + abs(qnorm(.025))*se_log_risk_ratio
     ob.disp.rr <- c(rr.a, exp(bm.ci.1), exp(bm.ci.2))
     
     mu1 <- mean(data.m$los[data.m$afam == 1])
     mu0 <- sum(data.m$los[data.m$afam == 0] * data.m$allow.y.wts[data.m$afam == 0]) / sum(data.m$afam == 1)

     pe.l <-  mu1 - mu0
     se1 <- sqrt(var(data.m$los[data$afam == 1]) / sum(data.m$afam == 1))
     se2 <- sqrt(sum((data$Y.res.l[data.m$afam == 0])^2 * data.m$allow.y.wts[data.m$afam == 0]^2) / sum(data.m$allow.y.wts[data.m$afam == 0])^2)
     bm.se <- se1 + se2
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     ob.disp.los <- c(pe.l, bm.ci.1, bm.ci.2)	
 
     ## Stochastic
     mu1 <- mean(data.m$adverse[data.m$afam == 1])
     mu1_stoch <- mean(weights.stoc$weights * data.m$adverse[data.m$afam == 1])
     mu0 <- sum(data.m$adverse[data.m$afam == 0] * data.m$allow.y.wts[data.m$afam == 0]) / sum(data.m$afam == 1)
     
     v1 <- var(data.m$adverse[data.m$afam == 1]) / sum(data.m$afam == 1)
     v1_stoch <- sum((data.m$Y.res.a[data.m$afam == 1])^2 * weights.stoc$weights^2) / sum(weights.stoc$weights)^2
     v0 <- sum((data.m$Y.res.a[data.m$afam == 0])^2 * data.m$allow.y.wts[data.m$afam == 0]^2) / sum(data.m$allow.y.wts[data.m$afam == 0])^2

     pe.a <- mu1 - mu1_stoch
     bm.se <- sqrt(v1) + sqrt(v1_stoch)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     post.int <- c(pe.a, bm.ci.1, bm.ci.2)
     rm(pe.a, bm.se, bm.ci.1, bm.ci.2)
 
     ## Remaining Disparity
     pe.a <- mu1_stoch - mu0
     bm.se <- sqrt(v0) + sqrt(v1_stoch)
     bm.ci.1 <- pe.a - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.a + abs(qnorm(.025))*bm.se
     remain.disp <- c(pe.a, bm.ci.1, bm.ci.2)
     
     ## LOS
     mu1 <- mean(data.m$los[data.m$afam == 1])
     mu1_stoch <- mean(weights.stoc$weights * data.m$los[data.m$afam == 1])
     mu0 <- sum(data.m$los[data.m$afam == 0] * data.m$allow.y.wts[data.m$afam == 0]) / sum(data.m$afam == 1)
     
    
     se1 <- sqrt(var(data.m$los[data$afam == 1]) / sum(data.m$afam == 1))
     se1_stoch <- sqrt(sum((data.m$Y.res.l[data.m$afam == 1])^2 * weights.stoc$weights^2) / sum(weights.stoc$weights)^2)
     se0 <- sqrt(sum((data.m$Y.res.l[data.m$afam == 0])^2 * data.m$allow.y.wts[data.m$afam == 0]^2) / sum(data.m$allow.y.wts[data.m$afam == 0])^2)
     
     pe.l <- mu1 - mu1_stoch
     bm.se <- se1 + se1_stoch
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     post.int.los <- c(pe.l, bm.ci.1, bm.ci.2)
 
     ## Remaining Disparity
     pe.l <- mu1_stoch - mu0
     bm.se <- se1_stoch + se0
     bm.ci.1 <- pe.l - abs(qnorm(.025))*bm.se
     bm.ci.2 <- pe.l + abs(qnorm(.025))*bm.se
     remain.disp.los <- c(pe.l, bm.ci.1, bm.ci.2)
               		  

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(ob.disp,
   ob.disp.rr,
   ob.disp.los,
   post.int,
   remain.disp,
   post.int.los,
   remain.disp.los,
   file ="new-wts.outcomes.RData")


                    
