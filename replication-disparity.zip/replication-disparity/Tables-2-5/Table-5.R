
library(foreign)
library(dplyr)
library(tidyverse)
library(sandwich)
library(geepack)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("wts.out.RData")

data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)

data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
data$los[data$los>30] <- 30

setwd("/Volumes/C-SHE/Keele/Template Ranks/Analysis/ReplicationFiles/routput")
load("ridge-resid.RData") 
data$Y.res.a <- rd.resid.a
data$Y.res.l <- rd.resid.l
nrow(data)
length(rd.resid.a)
data <- data %>% filter(afam_ct>=15)
nrow(data)

# Process the Weights
data.s <- data %>% filter(surg==1)
data.ns <- data %>% filter(surg==0)

data.m <- rbind(data.s, data.ns)

n.a <- nrow(data %>% filter(afam == 1))
n <- nrow(data)
n.w <- nrow(data %>% filter(afam == 0))

g101 <- group1_w0.h$weights * data.m$adverse[data.m$afam == 1]
g111 <- group1_w1.h$weights * data.m$adverse[data.m$afam == 1]
g000 <- group0_w0.h$weights * data.m$adverse[data.m$afam == 0]
g010 <- group0_w1.h$weights * data.m$adverse[data.m$afam == 0]

mu101 <- mean(g101)
mu111 <- mean(g111)
mu000 <- mean(g000)
mu010 <- mean(g010)

v101 <- sum((data.m$Y.res.a[data.m$afam == 1])^2 * group1_w0.h$weights^2) / sum(group1_w0.h$weights)^2
v111 <- sum((data.m$Y.res.a[data.m$afam == 1])^2 * group1_w1.h$weights^2) / sum(group1_w1.h$weights)^2   
v000 <- sum((data.m$Y.res.a[data.m$afam == 0])^2 * group0_w0.h$weights^2) / sum(group0_w0.h$weights)^2  
v010 <- sum((data.m$Y.res.a[data.m$afam == 0])^2 * group0_w1.h$weights^2) / sum(group0_w1.h$weights)^2
 
# proportions of surgery per group
p1 <- mean(data.m$surg[data.m$afam == 1])
p0 <- mean(data.m$surg[data.m$afam == 0])

vp1 <- p1*(1 - p1)/n.a
vp0 <- p0*(1 - p0)/n.w

# decomposition elements
total <- mean(data.m$adverse[data.m$afam == 1]) - mean(data.m$adverse[data.m$afam == 0])
baseline <- mu101 - mu000
prevalence <-  (p1 - p0) * (mu010 - mu000)
effect <- p1 * (mu111 - mu101 - mu010 + mu000)
selection <- total - baseline - prevalence - effect


t.var <- mean(data.m$adverse[data.m$afam == 1])*(1  - mean(data.m$adverse[data.m$afam == 1]))/n
b.var <- v101 + v000
p.var <- ((p1 - p0)^2)*(v010+v000) 
e.var <- p1^2*(v111+v101+v010+v000) 
s.var <- t.var + p1^2*v111+p0^2*v010+(1-p0)^2*v000+(1-p1)^2*v101


tot <- c(total, total - abs(qnorm(.025))*sqrt(t.var), total + abs(qnorm(.025))*sqrt(t.var))
base <- c(baseline, baseline - abs(qnorm(.025))*sqrt(b.var), baseline + abs(qnorm(.025))*sqrt(b.var))
prev <- c(prevalence, prevalence - abs(qnorm(.025))*sqrt(p.var), prevalence + abs(qnorm(.025))*sqrt(p.var))
eff <- c(effect, effect - abs(qnorm(.025))*sqrt(e.var), effect + abs(qnorm(.025))*sqrt(e.var))
select <- c(selection, selection - abs(qnorm(.025))*sqrt(s.var), selection + abs(qnorm(.025))*sqrt(s.var))


## LOS

g101 <- group1_w0.h$weights * data.m$los[data.m$afam == 1]
g111 <- group1_w1.h$weights * data.m$los[data.m$afam == 1]
g000 <- group0_w0.h$weights * data.m$los[data.m$afam == 0]
g010 <- group0_w1.h$weights * data.m$los[data.m$afam == 0]

mu101 <- mean(g101)
mu111 <- mean(g111)
mu000 <- mean(g000)
mu010 <- mean(g010)

v101 <- sum((data.m$Y.res.l[data.m$afam == 1])^2 * group1_w0.h$weights^2) / sum(group1_w0.h$weights)^2
v111 <- sum((data.m$Y.res.l[data.m$afam == 1])^2 * group1_w1.h$weights^2) / sum(group1_w1.h$weights)^2   
v000 <- sum((data.m$Y.res.l[data.m$afam == 0])^2 * group0_w0.h$weights^2) / sum(group0_w0.h$weights)^2  
v010 <- sum((data.m$Y.res.l[data.m$afam == 0])^2 * group0_w1.h$weights^2) / sum(group0_w1.h$weights)^2
 
# proportions of surgery per group
p1 <- mean(data.m$surg[data.m$afam == 1])
p0 <- mean(data.m$surg[data.m$afam == 0])

# decomposition elements
total.los <- mean(data.m$los[data.m$afam == 1]) - mean(data.m$los[data.m$afam == 0])
baseline.los <- mu101 - mu000
prevalence.los <-  (p1 - p0) * (mu010 - mu000)
effect.los <- p1 * (mu111 - mu101 - mu010 + mu000)
selection.los <- total.los - baseline.los - prevalence.los - effect.los

t.var.los <- var(data.m$los)
b.var.los <- v101 + v000
p.var.los <- ((p1 - p0)^2)*(v010+v000)
e.var.los <- p1^2*(v111+v101+v010+v000)
s.var.los <- t.var.los + p1^2*v111+p0^2*v010+(1-p0)^2*v000+(1-p1)^2*v101


tot.los <- c(total.los, total.los - abs(qnorm(.025))*(sqrt(t.var.los/n)), total.los + abs(qnorm(.025))*(sqrt(t.var.los/n)))
base.los <- c(baseline.los, baseline.los - abs(qnorm(.025))*(sqrt(b.var.los)), baseline.los + abs(qnorm(.025))*(sqrt(b.var.los)))
prev.los <- c(prevalence.los, prevalence.los - abs(qnorm(.025))*(sqrt(p.var.los)), prevalence.los + abs(qnorm(.025))*(sqrt(p.var.los)))
eff.los <- c(effect.los, effect.los - abs(qnorm(.025))*(sqrt(e.var.los)), effect.los + abs(qnorm(.025))*(sqrt(e.var.los)))
select.los <- c(selection.los, selection.los - abs(qnorm(.025))*(sqrt(s.var.los/n)), selection.los + abs(qnorm(.025))*(sqrt(s.var.los/n)))
              		  

sqrt(var(data.m$los))
setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(tot, base, prev, eff, select,
     tot.los, base.los, prev.los, eff.los, select.los,
   file ="decomp.two.outcomes.RData")


                    
