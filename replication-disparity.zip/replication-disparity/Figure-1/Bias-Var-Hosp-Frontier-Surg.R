
library(tidyverse)
library(balancer)
library(foreign)
library(splines)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)

data <- data %>% filter(afam_ct>=20)
data <- data %>% filter(hisp==0)
nrow(data)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
nrow(data)

data <- data %>% filter(surg==1)

age.sp <- ns(data$age, df=6, intercept=FALSE)
nos <- seq(1:ncol(age.sp))
colnames(age.sp) <- paste("agesp", nos, sep="")
data <- cbind(data, age.sp)

vars <-  c(colnames(age.sp), "comorb", "female",
          "angus", "disability_bin","under65",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "angus:ynel21", "angus:comorb", "angus:ynel1", "angus:ynel13",
           "angus:ynel31", "angus:ynel23",  "angus:disability_bin",
           "under65:p_cat1", "under65:comorb", "under65:ynel3","comorb:ynel1",
           "under65:disability_bin", "ynel1:ynel3", "ynel2:ynel24", "-1")    
            
basis <- reformulate(vars)                 
              
X <- scale(model.matrix(as.formula(basis), data))
trt <- data$afam
Z <- data$hospid

bal.data <- as.data.frame(model.matrix(as.formula(basis), data))
bal.names <- names(bal.data)
bal.data$afam <- data$afam
bal.data$hospid <- data$hospid

data.var <- bal.data %>% group_by(afam) %>% 
   summarize(across(bal.names, ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.sd <- sqrt((t.var + c.var/2))

lambda <- seq(0, 100, 10)
n.k <- length(lambda)
ess <- matrix(NA, n.k, 1)
bias <- matrix(NA, n.k, 1)

um.wt <- bal.data %>% group_by(hospid, afam) %>% 
   summarize(across(bal.names, ~mean(.x))) %>% as.data.frame()
         
          
          
       row.odd <- seq_len(nrow(um.wt))  %% 2
       wht.u <- t(um.wt[row.odd == 1,c(-1:-2)])
       afm.u <- t(um.wt[row.odd == 0,c(-1:-2)])
       diff.un.wt <- afm.u - wht.u
       std.diff.un.wt <- diff.un.wt/pooled.sd
       n.hosp <- length(unique(bal.data$hospid))
       n.cov <- length(bal.names)
       vec.dim <- n.hosp*n.cov
       um.wt.bias <- matrix(std.diff.un.wt, vec.dim ,1)
                 
for(i in 1:n.k){
	bal.lambda.tmp <- multilevel_qp(X, trt, Z, lambda = lambda[i], verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)
    bal.data.tmp <- bal.data
    bal.data.tmp$wts <- pmax(bal.lambda.tmp$weights, 0)
    bal.data.tmp$wts[bal.data.tmp$afam == 1] <- 1
    ess[i,] <- (sum(bal.data.tmp$wts)^2) / (sum(bal.data.tmp$wts^2)) 

   bal.tmp <- bal.data.tmp %>% group_by(hospid, afam) %>% 
   summarize(across(bal.names, ~ weighted.mean(.x, wts))) %>% as.data.frame()
   wht.b.h <- t(bal.tmp[row.odd == 1,c(-1:-2)])
   afm.b.h <- t(bal.tmp[row.odd == 0,c(-1:-2)])
   diff.b.h <- afm.b.h - wht.b.h
   std.diff.b.h <- diff.b.h/pooled.sd
   wt.bias <- matrix(std.diff.b.h, vec.dim ,1)   
          
	bias[i,] <- (1 - (mean(abs(wt.bias))/mean(abs(um.wt.bias))))*100
   }

out.dat.hosp.restrt <- as.data.frame(cbind(lambda, ess,  bias))
names(out.dat.hosp.restrt) <- c("lambda", "ess", "bias")
out.dat.hosp.restrt 

ess <- matrix(NA, n.k, 1)
bias <- matrix(NA, n.k, 1)

for(i in 1:n.k){
	bal.lambda.tmp <- multilevel_qp(X, trt, Z, lambda = lambda[i], lowlim = -Inf, uplim = Inf, verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)
    bal.data.tmp <- bal.data
    bal.data.tmp$wts <- bal.lambda.tmp$weights
    bal.data.tmp$wts[bal.data.tmp$afam == 1] <- 1
    ess[i,] <- (sum(bal.data.tmp$wts)^2) / (sum(bal.data.tmp$wts^2)) 

   bal.tmp <- bal.data.tmp %>% group_by(hospid, afam) %>% 
   summarize(across(bal.names, ~ weighted.mean(.x, wts))) %>% as.data.frame()
   wht.b.h <- t(bal.tmp[row.odd == 1,c(-1:-2)])
   afm.b.h <- t(bal.tmp[row.odd == 0,c(-1:-2)])
   diff.b.h <- afm.b.h - wht.b.h
   std.diff.b.h <- diff.b.h/pooled.sd
   wt.bias <- matrix(std.diff.b.h, vec.dim ,1)   
          
	bias[i,] <- (1 - (mean(abs(wt.bias))/mean(abs(um.wt.bias))))*100
   }

out.dat.hosp.unrestrt <- as.data.frame(cbind(lambda, ess,  bias))
names(out.dat.hosp.unrestrt) <- c("lambda", "ess", "bias")
out.dat.hosp.unrestrt 

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(out.dat.hosp.restrt, out.dat.hosp.unrestrt, file ="bias-var-hosp-surg.RData")




