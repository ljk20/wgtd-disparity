
library(tidyverse)
library(scales)
library(xtable)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("bias-var-hosp-surg.RData")


out.dat.hosp.restrt
row.names(out.dat.hosp.restrt) <- out.dat.hosp.restrt$lambda

plot.hosp.restrt <- ggplot(out.dat.hosp.restrt, aes(x=ess, y=bias)) +
		      geom_point() +
		      geom_line(size=1) +
              geom_text(aes(label = rownames(out.dat.hosp.restrt)), hjust=-.15, nudge_x = 1.5, nudge_y = .25) +
		      xlab("Effective Sample Size") +
		      ylab("Proportional Reduction in Bias (%)") +
		      theme_bw() 
plot.hosp.restrt

setwd("~/Dropbox/Bal-Weights/draft/figures-pre")
pdf("bias-var-surg.pdf", width=7.1, height=6, onefile=FALSE, paper="special")
plot.hosp.restrt
dev.off()



rm(list=ls())
setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("bias-var-hosp-total.RData")


out.dat.hosp.restrt
row.names(out.dat.hosp.restrt) <- out.dat.hosp.restrt$lambda

plot.hosp.restrt <-ggplot(out.dat.hosp.restrt, aes(x=ess, y=bias)) +
		      geom_point() +
		      geom_line(size=1) +
              geom_text(aes(label = rownames(out.dat.hosp.restrt)), hjust=-.15, nudge_x = 1.5, nudge_y = .25) +
		      xlab("Effective Sample Size") +
		      ylab("Proportional Reduction in Bias (%)") +
		      theme_bw()  + 
		      scale_x_continuous(labels = comma, limits=c(55000, 114000))
		      
setwd("~/Dropbox/Bal-Weights/draft/figures-pre")
pdf("bias-var-total.pdf", width=7.1, height=6, onefile=FALSE, paper="special")
plot.hosp.restrt
dev.off()