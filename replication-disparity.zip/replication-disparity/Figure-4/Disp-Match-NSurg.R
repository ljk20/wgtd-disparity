library(foreign)
library(rcbalance)
library(rcbsubset)
library(dplyr)
library(splines)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)

data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)
nrow(data)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
nrow(data)

age.sp <- ns(data$age, df=6, intercept=FALSE)
nos <- seq(1:ncol(age.sp))
colnames(age.sp) <- paste("age", nos, sep="")
data <- cbind(data, age.sp)

n.pat <- table(data$afam)
n.pat

data <- data %>% filter(surg==0)

vars <-  c(colnames(age.sp), "comorb", "female",
          "angus", "disability_bin","under65",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "angus:ynel21", "angus:comorb", "angus:ynel1", "angus:ynel13",
           "angus:ynel31", "angus:ynel23",  "angus:disability_bin",
           "under65:p_cat1", "under65:comorb", "under65:ynel3","comorb:ynel1",
           "under65:disability_bin", "ynel1:ynel3", "ynel2:ynel24", "-1")    


basis <- reformulate(vars)                        
X.mat <- m.data <- as.data.frame(model.matrix(as.formula(basis), data))
m.data$afam <- data$afam
          
# Build Distance Matrix
t_fexact <- system.time({
my.dist <- build.dist.struct(z=m.data$afam == 1, X=X.mat,
                             calip.option = "propensity", 
                             caliper = 0.15, exact=data$hospid)


#define fine balance levels - by order of balance priority.
l1 <- c("under65")
l2 <- c(l1, "ynel1:ynel3")
l3 <- c(l2, "ynel2:ynel24")


# Exclude Treated Units

match.out <- rcbalance(my.dist,
                         treated.info = m.data[m.data$afam == 1,],
                         control.info = m.data[m.data$afam != 1,], 
                         exclude.treated = TRUE, tol = .1)
})

# time required for the p-value computation, in minutes
t_fexact[['elapsed']]/60

##########################
#Post Match Processing
##########################

# Separate Original Data
t.dat <- data[data$afam==1,]
c.dat <- data[data$afam==0,]

# Extract Matched Treated
match.treat <- t.dat[as.numeric(rownames(match.out$matches)),]
n <- nrow(match.treat)

# Create Pair Id
match.treat$pair.id <- 1:n

# Extract Matched Controls
match.ctrl <- c.dat[match.out$matches,]
match.ctrl$pair.id <- 1:n

# Put Matched Data Back Together
match.data <- rbind(match.treat, match.ctrl)
head(match.data)

table(m.data$afam)
table(match.data$afam)

nrow(m.data)
nrow(match.data)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(match.data, file ="match.out.nsurg.RData")	



