


### Packages
library("vivid") # for visualisations
library("ISLR") # for data
#library("randomForest") # to create model
library("condvis2") # for predict function
library(foreign)
library(tidymodels)
library("ranger")
library(doParallel)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)
data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
data <- data %>% filter(afam_ct>=10)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data.train <- data[train, ]
data.test <- data[-train, ]


nrow(data.train)
table(data.train$afam)

## Estimate Random Forest
vars <-  c("age", "female", "under65")

vars %in% names(data.train)

data.est = data.train[,c("adverse",vars)]


tree_rec <- recipe(adverse ~ ., data = data.est)
tree_prep <- prep(tree_rec)
juiced <- juice(tree_prep)

tune_spec <- rand_forest(
             mtry = tune(),
             trees = 1000,
             min_n = tune()
             ) %>%
             set_mode("regression") %>%
             set_engine("ranger")
             
tune_wf <- workflow() %>%
           add_recipe(tree_rec) %>%
           add_model(tune_spec)
           
set.seed(343)
tree_folds <- vfold_cv(data.train)

doParallel::registerDoParallel()

set.seed(321)

t_fexact <- system.time({ 
tune_res <- tune_grid(
            tune_wf,
            resamples = tree_folds,
            grid= 20) 
})

t_fexact[['elapsed']]/60

tune_res %>%
   collect_metrics() %>%
   filter(.metric == "rmse") %>%
   select(mean, min_n, mtry) %>%
   pivot_longer(min_n:mtry,
   values_to = "value",
   names_to = "parameter") %>%
   ggplot(aes(value, mean, color = parameter)) +
   geom_point(show.legend = FALSE) +
   facet_wrap(~parameter, scales = "free_x") +
   labs(x = NULL, y = "RMSE") + theme_bw()

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(tune_res, file ="rf-tune-y-alllow.RData")

        
best_rmse <- select_best(tune_res, "rmse")
best_rmse
        	        
## Model fitting:
# Fit a random forest model
set.seed(101)
rf <- ranger(adverse ~ ., data = data.est, mtry = 2, min.node.size = 21, importance = "impurity")

set.seed(3456)
vividMatrixRF <- vivi(data.est, 
                      rf, "adverse",
                      gridSize = 10, 
                      reorder = FALSE)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")                      
save(vividMatrixRF, file ="rf-vivid-y-alllow.RData")                      
                      
