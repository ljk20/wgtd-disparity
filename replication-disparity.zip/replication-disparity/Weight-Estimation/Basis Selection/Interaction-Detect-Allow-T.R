


### Packages
library("vivid") # for visualisations
library("ISLR") # for data
#library("randomForest") # to create model
library("condvis2") # for predict function
library(foreign)
library(tidymodels)
library("ranger")
library(doParallel)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)
data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
data <- data %>% filter(afam_ct>=10)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data.train <- data[train, ]
data.test <- data[-train, ]


nrow(data.train)
table(data.train$afam)

## Estimate Random Forest
vars <-  trt_vars <- c("comorb", "angus", "disability_bin",
            "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51")

vars %in% names(data.train)

data.est = data.train[,c("adverse",vars)]


tree_rec <- recipe(adverse ~ ., data = data.est)
tree_prep <- prep(tree_rec)
juiced <- juice(tree_prep)

tune_spec <- rand_forest(
             mtry = tune(),
             trees = 1000,
             min_n = tune()
             ) %>%
             set_mode("regression") %>%
             set_engine("ranger")
             
tune_wf <- workflow() %>%
           add_recipe(tree_rec) %>%
           add_model(tune_spec)
           
set.seed(343)
tree_folds <- vfold_cv(data.train)

doParallel::registerDoParallel()

set.seed(321)

t_fexact <- system.time({ 
tune_res <- tune_grid(
            tune_wf,
            resamples = tree_folds,
            grid= 20) 
})

t_fexact[['elapsed']]/60

tune_res %>%
   collect_metrics() %>%
   filter(.metric == "rmse") %>%
   select(mean, min_n, mtry) %>%
   pivot_longer(min_n:mtry,
   values_to = "value",
   names_to = "parameter") %>%
   ggplot(aes(value, mean, color = parameter)) +
   geom_point(show.legend = FALSE) +
   facet_wrap(~parameter, scales = "free_x") +
   labs(x = NULL, y = "RMSE") + theme_bw()

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(tune_res, file ="rf-tune-t-alllow.RData")

        
best_rmse <- select_best(tune_res, "rmse")
best_rmse
        	        
## Model fitting:
# Fit a random forest model
set.seed(101)
rf <- ranger(adverse ~ ., data = data.est, mtry = 8, min.node.size = 24, importance = "impurity")

set.seed(3456)
vividMatrixRF <- vivi(data.est, 
                      rf, "adverse",
                      gridSize = 10, 
                      reorder = FALSE)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")                      
save(vividMatrixRF, file ="rf-vivid-t-alllow.RData")                      
                      
