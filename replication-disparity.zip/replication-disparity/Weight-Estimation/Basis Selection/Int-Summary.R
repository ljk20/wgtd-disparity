### Packages
library("vivid") # for visualisations
library("ISLR") # for data
library("condvis2") # for predict function
library(foreign)
library(tidymodels)
library("ranger")
library(gridExtra)

rm(list=ls())


setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("rf-vivid-nsurg.RData")   
                    
# Sort matrix:
vividMatrixRFSorted <- vividReorder(vividMatrixRF)

viviHeatmap(vividMatrixRFSorted, angle = 45) # sorted heatmap

# More Refined Interaction Identification
viviNetwork(vividMatrixRFSorted)

intVals <- as.dist(vividMatrixRFSorted)
intVals <- as.matrix(intVals)

sv <- which(diag(vividMatrixRFSorted) > 10 | apply(intVals, 1, max) > .01)
h <- hclust(-as.dist(vividMatrixRFSorted[sv,sv]), method="single")

p1 <- viviNetwork(vividMatrixRFSorted[sv,sv],
			intThreshold = 0.001,
			removeNode = T,
			cluster = cutree(h,3))
			

setwd("/Users/ljk20/Dropbox/Bal-Weights/draft/figures-pre")
pdf("int-plot-nsurg.pdf", width=7, height=7, onefile=FALSE, paper="special")	

p1			
dev.off()			
			
#rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("rf-vivid-surg.RData")   
                    
# Sort matrix:
vividMatrixRFSorted <- vividReorder(vividMatrixRF)

viviHeatmap(vividMatrixRFSorted, angle = 45) # sorted heatmap

# More Refined Interaction Identification
viviNetwork(vividMatrixRFSorted)

intVals <- as.dist(vividMatrixRFSorted)
intVals <- as.matrix(intVals)

sv <- which(diag(vividMatrixRFSorted) > 10 | apply(intVals, 1, max) > .01)
h <- hclust(-as.dist(vividMatrixRFSorted[sv,sv]), method="single")

p2 <- viviNetwork(vividMatrixRFSorted[sv,sv],
			intThreshold = 0.001,
			removeNode = T,
			cluster = cutree(h,3))
			
setwd("/Users/ljk20/Dropbox/Bal-Weights/draft/figures-pre")
pdf("int-plot-surg.pdf", width=7, height=7, onefile=FALSE, paper="special")	
p2
dev.off()			

#rm(list=ls())

load("/Volumes/C-SHE/Keele/Bal-Weights/routput/rf-vivid-y-alllow.RData")
                    
# Sort matrix:
vividMatrixRFSorted <- vividReorder(vividMatrixRF)

viviHeatmap(vividMatrixRFSorted, angle = 45) # sorted heatmap

# More Refined Interaction Identification
viviNetwork(vividMatrixRFSorted)

intVals <- as.dist(vividMatrixRFSorted)
intVals <- as.matrix(intVals)

sv <- which(diag(vividMatrixRFSorted) > 10 | apply(intVals, 1, max) > .01)
h <- hclust(-as.dist(vividMatrixRFSorted[sv,sv]), method="single")

p3 <- viviNetwork(vividMatrixRFSorted[sv,sv],
			intThreshold = 0.001,
			removeNode = T,
			cluster = cutree(h,3))
			
setwd("/Users/ljk20/Dropbox/Bal-Weights/draft/figures-pre")
pdf("int-plot-y-allow.pdf", width=7, height=7, onefile=FALSE, paper="special")	
p3
dev.off()			
			
#rm(list=ls())

load("/Volumes/C-SHE/Keele/Bal-Weights/routput/rf-vivid-t-alllow.RData")
                    
# Sort matrix:
vividMatrixRFSorted <- vividReorder(vividMatrixRF)

viviHeatmap(vividMatrixRFSorted, angle = 45) # sorted heatmap

# More Refined Interaction Identification
viviNetwork(vividMatrixRFSorted)

intVals <- as.dist(vividMatrixRFSorted)
intVals <- as.matrix(intVals)

sv <- which(diag(vividMatrixRFSorted) > 10 | apply(intVals, 1, max) > .01)
h <- hclust(-as.dist(vividMatrixRFSorted[sv,sv]), method="single")

p4 <- viviNetwork(vividMatrixRFSorted[sv,sv],
			intThreshold = 0.001,
			removeNode = T,
			cluster = cutree(h,3))
			
setwd("/Users/ljk20/Dropbox/Bal-Weights/draft/figures-pre")
pdf("int-plot-t-allow.pdf", width=7, height=7, onefile=FALSE, paper="special")	
p4
dev.off()


setwd("/Users/ljk20/Dropbox/Bal-Weights/draft/figures-pre")
pdf("basis-plot.pdf", width=10, height=10, onefile=FALSE, paper="special")
grid.arrange(p1, p2, p3, p4, nrow=2, ncol = 2, widths = c(1,1))
dev.off() 

			
							