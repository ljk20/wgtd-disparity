
library(tidyverse)
library(balancer)
library(foreign)
library(splines)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)

data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)
data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
nrow(data)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
nrow(data)

age.sp <- ns(data$age, df=6, intercept=FALSE)
nos <- seq(1:ncol(age.sp))
colnames(age.sp) <- paste("agesp", nos, sep="")
data <- cbind(data, age.sp)


data.s <- data %>% filter(surg==1)
data.ns <- data %>% filter(surg==0)

vars <-  c(colnames(age.sp), "comorb", "female",
          "angus", "disability_bin","under65",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "angus:ynel21", "angus:comorb", "angus:ynel1", "angus:ynel13",
           "angus:ynel31", "angus:ynel23",  "angus:disability_bin",
           "under65:p_cat1", "under65:comorb", "under65:ynel3","comorb:ynel1",
           "under65:disability_bin", "ynel1:ynel3", "ynel2:ynel24", "-1")   

y_vars <- c(colnames(age.sp), "female", "under65", "age:female", "under65:age", "-1")
        

basis <-  c(vars)
X.s <- scale(model.matrix(reformulate(vars), data.s))
lambda.s <- var(lm(adverse ~ X.s, data.s, subset=(afam==0))$resid)
 
X.ns <- scale(model.matrix(reformulate(vars), data.ns))
lambda.ns <- var(lm(adverse ~ X.ns, data.ns, subset=(afam==0))$resid)

X.y <- scale(model.matrix(reformulate(y_vars), data))
lambda.y <- var(lm(adverse ~ X.y, data, subset=(afam==0))$resid)

X <- scale(model.matrix(reformulate(vars), data))
lambda.stoc <- var(lm(surg ~ X, data, subset=(afam==0))$resid)
 
setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(lambda.s, lambda.ns, lambda.y, lambda.stoc, file ="lambda.values.RData")


lambda.s
lambda.ns
lambda.y.s
lambda.y.ns
lambda.stoc 