
library(foreign)
library(balancer)
library(dplyr)
library(splines)
library(glmnet)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)
nrow(data)

data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)
nrow(data)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
nrow(data)

age.sp <- ns(data$age, df=6, intercept=FALSE)
nos <- seq(1:ncol(age.sp))
colnames(age.sp) <- paste("age", nos, sep="")
data <- cbind(data, age.sp)

n.pat <- table(data$afam)
n.pat

data.s <- data %>% filter(surg==1)
nrow(data.s)
data.ns <- data %>% filter(surg==0)
nrow(data.ns)

vars <-  c(colnames(age.sp), "comorb", "female",
          "angus", "disability_bin","under65",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "angus:ynel21", "angus:comorb", "angus:ynel1", "angus:ynel13",
           "angus:ynel31", "angus:ynel23",  "angus:disability_bin",
           "under65:p_cat1", "under65:comorb", "under65:ynel3","comorb:ynel1",
           "under65:disability_bin", "ynel1:ynel3", "ynel2:ynel24", "-1")          
           
             
trt_vars <-  c(colnames(age.sp), "comorb", 
          "angus", "disability_bin",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "ynel2:ynel3", "ynel5:shafi38", "ynel5:ynel31","ynel5:ynel20",
           "ynel31:ynel13","ynel2:comorb", "shafi35:angus","-1")  
           
                                  
X.s <- scale(model.matrix(reformulate(vars), data.s))
trt.s <- data.s$afam
Z.s <- data.s$state
n.s <- nrow(data.s)
 
X.ns <- scale(model.matrix(reformulate(vars), data.ns))
trt.ns <- data.ns$afam
Z.ns <- data.ns$state
n.ns <- nrow(data.ns)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("lambda.values.RData")


## Restricted Models

 # timing
t_fexact <- system.time({ 
	               
out.state.surg <- multilevel_qp(X.s, trt.s, rep(1,n.s), lambda = lambda.s, verbose= FALSE, exact_global = FALSE, scale_sample_size = FALSE)

})

# time required for computation, in minutes
t_fexact[['elapsed']]/60

 # timing
t_fexact <- system.time({ 
	               
out.state.nsurg <- multilevel_qp(X.ns, trt.ns, rep(1, n.ns), lambda = lambda.ns, verbose= FALSE, exact_global = FALSE, scale_sample_size = FALSE)

})

# time required for computation, in minutes
t_fexact[['elapsed']]/60

## With Hospital

Z.s <- data.s$hospid
Z.ns <- data.ns$hospid


 # timing
t_fexact <- system.time({ 
	               
out.hosp.surg <- multilevel_qp(X.s, trt.s, Z.s, lambda = lambda.s, verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)

})

# time required for computation, in minutes
t_fexact[['elapsed']]/60

 # timing
t_fexact <- system.time({ 
out.hosp.nsurg <- multilevel_qp(X.ns, trt.ns, Z.ns, lambda = lambda.ns,  verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)

})

## Allow Y
y_vars <- c(colnames(age.sp), "female", "under65", "age:female", "under65:age", "-1")
                   
#X.s <- scale(model.matrix(reformulate(y_vars), data.s))
#trt.s <- data.s$afam
#Z.s <- data.s$state
 
#X.ns <- scale(model.matrix(reformulate(y_vars), data.ns))
#trt.ns <- data.ns$afam
#Z.ns <- data.ns$state

#out.y.state.surg <- multilevel_qp(X.s, trt.s, Z.s, lambda = lambda.y, verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)
#out.y.state.nsurg <- multilevel_qp(X.ns, trt.ns, Z.ns, lambda = lambda.y, verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)

#Z.s <- data.s$hospid
#Z.ns <- data.ns$hospid

#out.y.hosp.surg <- multilevel_qp(X.s, trt.s, Z.s, lambda = lambda.y, verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)
#out.y.hosp.nsurg <- multilevel_qp(X.ns, trt.ns, Z.ns, lambda = lambda.y,  verbose= FALSE, exact_global = TRUE, scale_sample_size = FALSE)


### jackson weights
n.s <- nrow(data.s)
n.ns <- nrow(data.ns)
n <- nrow(data)


allow.y <- scale(model.matrix(reformulate(y_vars), data))
out.y <- multilevel_qp(allow.y, data$afam, lambda = lambda.y, Z = data$hospid, verbose= FALSE)

## Stochastic Intervention
basis_y <- reformulate(y_vars)                        
allow_y <- scale(model.matrix(reformulate(y_vars), data))

basis_trt <- reformulate(trt_vars)                        
allow_trt <- scale(model.matrix(reformulate(trt_vars), data))

fit <- cv.glmnet(cbind(allow_y, allow_trt)[data$afam == 0,], data$surg[data$afam == 0], family = "binomial")

# and get probabilities for the "1" group as the stochastic intervention
pscore0 <- predict(fit, cbind(allow_y, allow_trt)[data$afam == 1,], type = "response")

# create stochastic intervention matrix with probabilities of treatments
stoch_int <- cbind(1 - pscore0, pscore0)

# the matrix needs names (need to fix)
colnames(stoch_int) <- c(0,1)

## What About Non-Allowable Covariates At This Step ???
data.afam <- data %>% filter(afam == 1)
basis <- reformulate(vars)                        

X <- scale(model.matrix(as.formula(basis), data.afam))
Z <- data.afam$hospid

# now re-weight "1" group to the stochastic intervention (use all covariates, and stratify on hospital)
weights.stoc <- stochastic_int(X, data.afam$surg, stoch_int, Z = data.afam$hospid, lambda = lambda.stoc, exact_global = FALSE)



## elwert and yu weights

data <- data %>% filter(afam_ct>=15)

# sample sizes
n.a <- nrow(data %>% filter(afam == 1))
n <- nrow(data)
n.w <- nrow(data %>% filter(afam == 0))


all_trt_int <- cbind(numeric(n), rep(1, n))
colnames(all_trt_int) <- c(0, 1)
all_ctrl_int <- cbind(rep(1, n), numeric(n))
colnames(all_ctrl_int) <- c(0, 1)


X <- scale(model.matrix(as.formula(basis), data))
trt <- data$surg

group1_w0 <- stochastic_int(X[data$afam == 1, ], trt[data$afam == 1],
                            all_ctrl_int[data$afam == 1, ], rep(1, n.a),
                            lambda = lambda.stoc, exact_global = FALSE)
# group 1 average Y1
group1_w1 <- stochastic_int(X[data$afam == 1, ], trt[data$afam == 1],
                            all_trt_int[data$afam == 1, ], rep(1, n.a),
                            lambda = lambda.stoc, exact_global = FALSE)

# group 0 average y0
group0_w0 <- stochastic_int(X[data$afam == 0, ], trt[data$afam == 0],
                            all_ctrl_int[data$afam == 0, ], rep(1, n.w),
                            lambda = lambda.stoc, exact_global = FALSE)
# group 0 average Y1
group0_w1 <- stochastic_int(X[data$afam == 0, ], trt[data$afam == 0],
                            all_trt_int[data$afam == 0, ], rep(1, n.w),
                            lambda = lambda.stoc, exact_global = FALSE)
                            
                            
Z <- data$hospid
group1_w0.h <- stochastic_int(X[data$afam == 1, ], trt[data$afam == 1],
                            all_ctrl_int[data$afam == 1, ], Z[data$afam == 1],
                            lambda = lambda.stoc, exact_global = TRUE)
# group 1 average Y1
group1_w1.h <- stochastic_int(X[data$afam == 1, ], trt[data$afam == 1],
                            all_trt_int[data$afam == 1, ], Z[data$afam == 1],
                            lambda = lambda.stoc, exact_global = TRUE)

# group 0 average y0
group0_w0.h <- stochastic_int(X[data$afam == 0, ], trt[data$afam == 0],
                            all_ctrl_int[data$afam == 0, ], Z[data$afam == 0],
                            lambda = lambda.stoc, exact_global = TRUE)
# group 0 average Y1
group0_w1.h <- stochastic_int(X[data$afam == 0, ], trt[data$afam == 0],
                            all_trt_int[data$afam == 0, ], Z[data$afam == 0],
                            lambda = lambda.stoc, exact_global = TRUE)
                            
setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
save(out.state.surg,
out.state.nsurg,
out.hosp.surg,
out.hosp.nsurg,
group1_w0,
group1_w1,
group0_w0,
group0_w1,
group1_w0.h,
group1_w1.h,
group0_w0.h,
group0_w1.h,
out.y,
weights.stoc, file ="wts.out.RData")	


 

