
library(foreign)
library(dplyr)
library(tidyverse)
library(sandwich)
library(geepack)
library(splines)

rm(list=ls())

setwd("/Volumes/C-SHE/Keele/Bal-Weights/data/")
data <- read.dta("race-egs.dta", warn.missing.labels = FALSE)

setwd("/Volumes/C-SHE/Keele/Bal-Weights/routput")
load("wts.out.ur.RData")
load("wts.out.RData")

data$adverse <- as.numeric(data$died + data$prolonged + data$complication > 0)
data <- data %>% filter(afam_ct>=10)
data <- data %>% filter(hisp==0)

set.seed(1031)
train <- sample(nrow(data), round(.025*nrow(data)))
data <- data[-train, ]
data$los[data$los>30] <- 30

age.sp <- ns(data$age, df=6, intercept=FALSE)
nos <- seq(1:ncol(age.sp))
colnames(age.sp) <- paste("age", nos, sep="")
data <- cbind(data, age.sp)


setwd("/Volumes/C-SHE/Keele/Template Ranks/Analysis/ReplicationFiles/routput")
load("ridge-resid.RData") 
data$Y.res.a <- rd.resid.a
data$Y.res.l <- rd.resid.l
nrow(data)
length(rd.resid.a)


data$wts.hosp.ur <- out.hosp.ur$weights
data$wts.hosp.ur[data$afam == 1] <- 1

data$allow.y.wts <- out.y$weights
data$allow.y.wts[data$afam == 1] <- 1

data.s <- data %>% filter(surg==1)
data.ns <- data %>% filter(surg==0)

# Process the Weights
data.s$wts.hosp <- out.hosp.surg$weights
data.s$wts.hosp[data.s$afam == 1] <- 1

data.ns$wts.hosp <- out.hosp.nsurg$weights
data.ns$wts.hosp[data.ns$afam == 1] <- 1

data.s$wts.state <- out.state.surg$weights
data.s$wts.state[data.s$afam == 1] <- 1

data.ns$wts.state <- out.state.nsurg$weights
data.ns$wts.state[data.ns$afam == 1] <- 1

data.m <- rbind(data.s, data.ns)



## Negative Weight Extrapolation
## Overall
(mean((data$wts.hosp.ur < 0)))*100

## Standardized
exp.data <- data %>% filter(wts.hosp.ur < 0)

(sum(abs(exp.data$wts.hosp.ur))/sum(data$afam))*100

## By Hospital
nwt.data <- exp.data %>% group_by(hospid) %>% 
   summarize(n.wt = sum(abs(wts.hosp.ur)),
             n.eff = sum( wts.hosp.ur )^2 / sum( wts.hosp.ur^2 ),
             n.afam = mean(afam_ct),
             exp.ratio = (n.wt/n.afam)) %>% as.data.frame()
  
h4 <- ggplot(nwt.data, aes(abs(exp.ratio))) +
   geom_histogram( bins = 50, color="black", fill="lightblue") + theme_bw() +
    ylab("Number of Occurences") +
    scale_x_continuous("Effective Extrapolation %", labels = scales::percent) +
    geom_vline(xintercept = .16, linetype = "dotted", size = 1.5)
h4

setwd("~/Dropbox/Bal-Weights/draft/figures-pre")
pdf("hosp-neg-wgt-ratio-hist.pdf", width=6, height=6, onefile=FALSE, paper="special")
h4
dev.off()


sp1 <- ggplot(nwt.data, aes(n.afam,  abs(exp.ratio))) +
   ylab("Extrapolation Ratio") +
   xlab("Number of Black Patients per Hospital - Log Scale") + 
   geom_point(aes()) +
   theme_bw() +
   scale_y_continuous("Effective Extrapolation %", labels = scales::percent) +
   scale_x_continuous(trans='log10') 
sp1

   
setwd("~/Dropbox/Bal-Weights/draft/figures-pre")
pdf("hosp-neg-wgt-scatter.pdf", width=6, height=6, onefile=FALSE, paper="special")
sp1
dev.off()



## Balance
basis.vars <-  c(colnames(age.sp), "comorb", "female",
          "angus", "disability_bin","under65",
           "p_cat1", "p_cat2", "p_cat3", "p_cat4", "p_cat5",
           "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
           "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
           "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
           "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
           "ynel29","ynel30","ynel31",
           "shafi1","shafi2","shafi3","shafi4","shafi5","shafi6",
           "shafi7","shafi8","shafi9","shafi10","shafi11","shafi12",
           "shafi13","shafi14","shafi15","shafi16","shafi17","shafi18",
           "shafi19","shafi20","shafi21","shafi22","shafi23","shafi24",
           "shafi25","shafi26","shafi27","shafi28","shafi29","shafi30",
           "shafi31","shafi32","shafi33","shafi34","shafi35","shafi36",
           "shafi37","shafi38","shafi39","shafi40","shafi41","shafi42",
           "shafi43","shafi44","shafi45","shafi46","shafi47","shafi48",
           "shafi49","shafi50","shafi51",
           "angus:ynel21", "angus:comorb", "angus:ynel1", "angus:ynel13",
           "angus:ynel31", "angus:ynel23",  "angus:disability_bin",
           "under65:p_cat1", "under65:comorb", "under65:ynel3","comorb:ynel1",
           "under65:disability_bin", "ynel1:ynel3", "ynel2:ynel24", "-1")       
           
              
basis <- reformulate(basis.vars)                     
X <- model.matrix(as.formula(basis), data.m)

bal.data <- as.data.frame(X)
bal.names <- names(bal.data)
n_covs <- length(bal.names)
bal.data$afam <- data.m$afam
bal.data$hospid <- data.m$hospid
bal.data$wts.hosp <- data.m$wts.hosp
bal.data$wts.state <- data.m$wts.state

data.var <- bal.data %>% group_by(afam) %>% 
   summarize(across(bal.names, ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.sd <- sqrt((t.var + c.var/2))   

var_names <- c("Age Spline 1", "Age Spline 2", "Age Spline 3", "Age Spline 4", "Age Spline 5", "Age Spline 6",
               "No. Comorbidities", "Female",
               "Sepsis", "Disability","Under 65",
               "Medicare", "Medicaid", "Private Insurance", "Self Insurance", "Other",
               "Congestive Heart Failure",  "Cardiac Arrhythmias","Valvular Disease",
               "Pulmonary Circulation Disorders", "Peripheral Vascular Disorders",
               "Hypertension, Uncomplicated","Paralysis", "Other Neurological Disorders", 
               "Chronic Pulmonary Disease","Diabetes, Uncomplicated",
               "Diabetes, Complicated","Hypothyroidism", "Renal Failure","Liver Disease",
               "Peptic Ulcer Disease Excluding Bleeding","AIDS/HIV", "Lymphoma","Metastatic Cancer",
               "Solid Tumor Without Metastasis","Rheumatoid Arthritis/Collagen Vascular",
               "Coagulopathy","Obesity","Weight Loss","Fluid and Electrolyte Disorders",
               "Blood Loss Anemia","Deficiency Anemia","Alcohol Abuse","Drug Abuse",
               "Psychoses","Depression","Hypertension, Complicated",
               "Colorectal: Bleeding","Colorectal: Cancer","Colorectal: Colitis",
               "Colorectal: Diverticulitis","Colorectal: Fistula","Colorectal:Hemorrhage","Colorectal: Megacolon",
               "Colorectal:Colostomy/Ileostomy","Colorectal:Rectal Prolapse",
               "Colorectal: Regional Enteritis","Colorectal: Anorectal Stenosis, Polyp, Ulcer, NEC",
               "Gen Abdominal: RP Abscess","Gen Abdominal: Hemoperitoneum","Gen Abdominal: Abdominal Mass",
               "Gen Abdominal: Abdominal Pain","Gen Abdominal:
               Peritonitis","HPB: Gallstones and Related Diseases","HPB: Hepatic","HPB: Pancreatitis",
               "Hernia: Diaphragmatic","Hernia:Femoral","Hernia: Incisional",
               "Hernia:Inguinal","Hernia: Other","Hernia:Umbilical","Hernia:Ventral","Intestinal Obstruction: Adhesions",
               "Intestinal Obstruction:Incarcerated Hernias","Intestinal Obstruction: Intussusceptions",
               "Intestinal Obstruction: Obstruction",
               "Intestinal Obstruction: Volvulus","Resuscitation: Acute Respiratory Failure",
               "Resuscitation: Shock","Skin & Soft Tissue: Abscesses","Skin & Soft Tissue: Cellulitis",
               "Skin & Soft Tissue: Compartment Syndrome","Skin & Soft Tissue: Fasciitis",
               "Skin & Soft Tissue: Pressure Ulcers","Skin & Soft Tissue: Wound Care","Upper GI: Appendix",
               "Upper GI: Bleed","Upper GI: Bowel Perforation","Upper GI: Fistula",
               "Upper GI: Gastrostomy","Upper GI: Ileus","Upper GI: Meckel's","Upper GI: Peptic Ulcer Disease",
               "Upper GI: Small Intestinal Cancers","Vascular: Acute Intestinal Ischemia",
               "Vascular: Acute Peripheral Ischemia", "Vascular: Phlebitis",
               "Sepsis:Coagulopathy","Sepsis:Comorbidities", "Sepsis:Congestive Heart Failure",
               "Sepsis:Renal Failure",
               "Sepsis:Hypertension","Sepsis:Weight Loss","Sepsis:Disability",
               "Under 65:Medicare", "Under 65:Comorbidities","Under65:Valvular Disease",
               "Comorbidities:Congestive Heart Failure", "Under 65:Disability",
               "Congestive Heart Failure:Valvular Disease", 
               "Cardiac Arrhythmia:Fluid Disorders")
               
## Hospital Interaction Balance
um.wt <- bal.data %>% group_by(hospid, afam) %>% 
   summarize(across(bal.names, ~mean(.x))) %>% as.data.frame()

row.odd <- seq_len(nrow(um.wt))  %% 2
wht.u <- t(um.wt[row.odd == 1,c(-1:-2)])
afm.u <- t(um.wt[row.odd == 0,c(-1:-2)])
diff.un.wt <- afm.u - wht.u
std.diff.un.wt <- diff.un.wt/pooled.sd
n.hosp <- length(unique(bal.data$hospid))
n.cov <- length(bal.names)
vec.dim <- n.hosp*n.cov
um.wt.bias <- matrix(std.diff.un.wt, vec.dim ,1)	

 bal.hosp <- bal.data %>% group_by(hospid, afam) %>% 
   summarize(across(bal.names, ~ weighted.mean(.x, wts.hosp))) %>% as.data.frame()
   
wht.b.h <- t(bal.hosp[row.odd == 1,c(-1:-2)])
afm.b.h <- t(bal.hosp[row.odd == 0,c(-1:-2)])
diff.b.h <- afm.b.h - wht.b.h
std.diff.b.h <- diff.b.h/pooled.sd
hosp.wt.bias <- matrix(std.diff.b.h, vec.dim ,1)   

## Bias Reduction
(1 - (mean(abs(hosp.wt.bias))/mean(abs(um.wt.bias))))*100

## RMSI Plots
sq.mat.un.wt <- std.diff.un.wt^2
cov.vec.un.wt <- as.matrix(apply(sq.mat.un.wt, 1, mean))
cov.vec.un.wt <- sqrt(cov.vec.un.wt)

sq.mat.wt <- std.diff.b.h^2
cov.vec.wt <- as.matrix(apply(sq.mat.wt, 1, mean))
cov.vec.wt <- sqrt(cov.vec.wt)

rownames(cov.vec.un.wt) <- var_names
rownames(cov.vec.wt) <- var_names

cov.mat <- cbind(cov.vec.wt, cov.vec.un.wt)
rownames(cov.mat) <- var_names

## Balance Subset
lg.diff <- cov.mat[which(abs(cov.mat[,2]) > .2),]
age.sp <- apply(lg.diff[1:5,], 2, mean)

# Plots              			  
data.plot <- c(c(age.sp[1], lg.diff[c(-1:-5),1]), c(age.sp[2], lg.diff[c(-1:-5),2]))
data.plot <- as.data.frame(data.plot)
names(data.plot) <- "diff"
n_covs <- nrow(data.plot)
data.plot$contrast <- c(rep(1, (n_covs/2)), rep(2, (n_covs/2)))
data.plot$contrast <- factor(data.plot$contrast, levels = c(1,2), labels = c("Weighted", "Unweighted"))
data.plot$covariate <- as.factor(c("Age", rownames(lg.diff)[c(-1:-5)]))
data.plot$covariate <- factor(data.plot$covariate, 
                       levels = c("Age", "Under 65", "Medicare", "Medicaid", "Self Insurance",
                                  "Under 65:Medicare", "Under 65:Comorbidities",           
                                  "Hypothyroidism", "Renal Failure", "Hypertension, Complicated",
                                  "Colorectal: Megacolon", "Hernia:Femoral"))
         
setwd("~/Dropbox/Bal-Weights/draft/figures-pre")
pdf("rmse-diff-plot.pdf", width=8, height=12, onefile=FALSE, paper="special")	
ggplot(data=data.plot, aes(x=diff, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=1.75) + 
          scale_shape_manual(name= "Contrast", values=c(1,15)) + 
          xlab("Root-Mean Squared Imbalance") + ylab("Covariates") +
          scale_y_discrete(limits = rev(levels(data.plot$covariate))) +
          theme_bw()
                
dev.off()

